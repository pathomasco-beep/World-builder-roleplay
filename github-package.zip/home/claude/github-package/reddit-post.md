# I built a worldbuilding + immersive roleplay system using Claude Skills (two .skill files, free to download)

Over the past few months I've been building something I haven't seen done well before: a two-skill system where Claude acts as both a world architect and then a GM who runs that world as a living, reactive sandbox. Not a chatbot pretending to be a dungeon master. An actual simulation with faction AI, information asymmetry, economic systems, and permanent consequences.

The project is two Claude Skills that work together:

**World Builder** takes you through a guided 13-layer generation process (geography, resources, peoples, politics, government, economy, military, culture, technology, history, tensions, NPCs, secrets). Each layer builds on the previous ones and passes through you for validation before moving forward. It supports three modes: fully fictional worlds, historical sandboxes (real civilizations at a specific date), and hybrids. Every political entity and major NPC gets a reactive profile that defines how they'd respond to disruption, not just what they historically did.

**World Roleplay** is the GM engine. You upload the world files, create a character through conversation (no stat screens, no menus), and play. The world simulates independently of you: factions pursue their agendas, events fire on schedule, news travels at the speed of horseback. Your character only knows what someone with their background, profession, and social circle would realistically know. The rest is fog of war.

## What makes this different from "Claude, run a D&D game for me"

The core design principles that I think set this apart:

**The world doesn't care about you.** You're one person in a world of millions. If you do nothing, wars start and end, kings die, trade routes shift. You're not the chosen one unless you make yourself matter through action.

**Consequences are permanent.** Insult a king, get imprisoned. Sail into a storm unprepared, your ship sinks. Trust the wrong person, get betrayed. No "are you sure?" prompts, no plot armor.

**Information is earned.** Your character starts knowing almost nothing beyond their personal experience. Want to know what's happening in the capital? Travel there, or talk to someone who's been. Want to know commodity prices? Become a merchant, or hire one. The GM never volunteers information your character wouldn't have.

**NPCs are people.** Every NPC has their own agenda, knowledge limits, and biases. A merchant doesn't tell you about a conspiracy because the merchant doesn't know about it. NPCs lie, exaggerate, omit, and misremember. Not to frustrate you, but because that's what people do.

**No numbers visible to the player.** Skills, reputation, health, relationships: all tracked internally by Claude, all experienced through narrative. You don't see "+1 to negotiation." You notice that merchants respond differently to your counteroffers than they did three months ago.

## Technical overview for the curious

The system is around 7,600 lines of structured instructions across the two skills, split into reference files that Claude loads as needed:

The **world-builder** has references for realistic physical geography (tectonic logic, river behavior, climate zones), a full supernatural system design framework (works for magic, cultivation/qi, psionics, divine power, or tech), cross-layer consistency checks, a knowledge distribution map template, and layer dependency tracking for when you edit completed layers.

The **roleplay engine** has references for world simulation (background events, faction decision-making, news propagation with information degradation over distance), a prose narration style guide (targeting the richness of Guy Gavriel Kay crossed with the sharp edges of Joe Abercrombie), a full character skill system (mundane 0-20, with optional cultivation/supernatural scales), combat resolution (individual, group, siege, naval), economy and pricing, travel and exploration narration, creature generation, and a separate supernatural narration guide for non-cultivation worlds.

Session persistence uses a two-file system: a baseline snapshot at session start + an append-only turn log updated every turn. Between sessions, you download JSON files and re-upload them next time.

## The build process

I want to be transparent: I built these skills collaboratively with Claude. The vision, design philosophy, and creative direction are mine. The execution, the detailed reference files, the JSON schemas, the narration examples, all of that was produced in extended working sessions with Claude, iterating heavily. I'd describe the process as similar to working with a very capable co-author who can write 800 lines of consistent, structured content in one pass but needs you to tell them what to write and when they've drifted off course.

The skills went through multiple audit and optimization passes. We trimmed redundancy, added gap-filling content (combat expansion, economy reference, travel narration, creature generation, difficulty calibration, OOC handling), fixed stale references, and removed deprecated files. The result is leaner than it looks.

## Download and try it

Both skills are available on GitHub: **[LINK TO YOUR REPO]**

To install: download the `.skill` files and open them in Claude. They'll install automatically.

To use: start a conversation and say something like "I want to build a world" or describe the setting you have in mind. The world-builder skill will guide you through the process. When you're done, it'll tell you how to hand off to the roleplay engine.

**Requirements:** Claude Max plan (the skills are large and benefit from the extended context window, though they should work on Pro as well for smaller worlds).

## What I'm looking for

Feedback, honestly. I've been deep in this for a while and could use fresh eyes. Specifically:

- Does the world generation process feel too heavy or about right?
- Does the roleplay narration quality hold up over extended sessions?
- Are there gaps I've missed in the simulation? Situations where the GM doesn't know what to do?
- Is the difficulty too punishing by default? (There's a difficulty calibration system, but the default is hardcore.)

If you try it and run into issues, I'd love to hear about them. And if you build a world you're proud of, share it. I'm genuinely curious to see what other people make with this.
